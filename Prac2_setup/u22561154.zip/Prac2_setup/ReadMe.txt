The program was initially run on Macbook M1 so there is extra files that exist.
Had it working on VSCode.
In this case, a makefile was not needed at all, but I did add it in for the tutors to mark.
If it does not run on your side, I will gladly use my laptop to demo this.
Everything in the program needs to be present.

On Macbook I had to press 'command', 'shift' and 'B' together to create the app.

Then in the terminal I had to link my files again by typing the following command:
export DYLD_LIBRARY_PATH=/Users/yi-rou/Desktop/COS344/Prac2_setup/dependencies/lib:$DYLD_LIBRARY_PATH
The command above is the directory for where the file is located, so please link it correctly according to your directories.

Then afterwards we can run the following in the terminal:
./app

Then the window will open.